import React from "react";

const ChatContext = React.createContext();

export default ChatContext;